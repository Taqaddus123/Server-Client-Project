import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 8080);
        System.out.println("Connected to server. Start chatting...");

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        // Thread to read messages from server
        new Thread(() -> {
            try {
                String message;
                while ((message = in.readLine()) != null) {
                    System.out.println("Server: " + message);
                }
            } catch (IOException e) {
                System.out.println("Connection closed.");
            }
        }).start();

        // Main thread to send messages to server
        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
        String message;
        while ((message = userInput.readLine()) != null) {
            out.println(message);
        }

        socket.close();
    }
}
